<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css"
          integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">

    <link rel="stylesheet"
          href="fonts/specimen_files/specimen_stylesheet.css"
          type="text/css"
          charset="utf-8" />

    <link rel="stylesheet"
          href="fonts/stylesheet.css"
          type="text/css"
          charset="utf-8" />

    <link rel="stylesheet"
          href="css/estilo.css"
          type="text/css"
          charset="utf-8" />

    <title>40º Rodeio de Campo Bom</title>
  </head>
  <body>
    <main>
      <nav class="navbar sticky-top navbar-trans
                  navbar-toggleable-sm navbar-expand-lg
                  navbar-light navbar-trans navbar-inverse navbar-rodeio">

        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarTogglerDemo02"
                aria-controls="navbarTogglerDemo02"
                aria-expanded="false"
                aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="#"></a>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0" style="margin: auto;">
            <li class="nav-item active">
              <a class="nav-link" href="#">home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link separador" href="">|</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">ao vivo</a>
            </li>
            <li class="nav-item">
              <a class="nav-link separador" href="">|</a>
            </li>
            <li class="nav-item dropdown">
               <a href="#"
                  class="nav-link dropdown-toggle"
                  data-toggle="dropdown"
                  role="button"
                  aria-expanded="false">vídeos<span class="caret"></span></a>
                <ul class="dropdown-menu sub-menu" role="menu">
                   <li><a href="#" class="nav-link">Campeira</a></li>
                   <li><a href="#" class="nav-link separador">|</a></li>
                   <li><a href="#" class="nav-link">Artística</a></li>
                   <li><a href="#" class="nav-link separador">|</a></li>
                   <li><a href="#" class="nav-link">Esporte</a></li>
                </ul>
            </li>

            <li class="nav-item separador">
              <a class="nav-link" href="">|</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="#">rodeio</a>
            </li>
            <li class="nav-item separador">
              <a class="nav-link" href="">|</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="#">programação</a>
            </li>
            <li class="nav-item separador">
              <a class="nav-link" href="">|</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="#">localização</a>
            </li>
            <li class="nav-item separador">
              <a class="nav-link" href="">|</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="#">contato</a>
            </li>
          </ul>
        </div>
      </nav>

      <div class="row align-items-center justify-content-center"
           style="margin-bottom: 40px;">

        <div class="div-info">
          <p class="data">02 a 11 de</p>
          <p class="data">Março de 2018</p>
          <hr />
          <p class="info">Parque do Trabalhador</p>
          <p class="info">Campo Bom/RS</p>
        </div>

        <img src="imagens/logo_rodeio.png"
             alt="Logotipo 40º Rodeio de Campo Bom."
             class="logotipo-rodeio" />

        <div class="div-info-mobile">
          <p class="data">02 a 11 de</p>
          <p class="data">Março de 2018</p>
          <hr />
          <p class="info">Parque do Trabalhador</p>
          <p class="info">Campo Bom/RS</p>
        </div>

      </div>

      <div class="row align-items-center justify-content-center">
        <img src="imagens/aovivo.png"
             alt="Ao vivo"
             class="img-info" />
      </div>

      <div class="container ao-vivo-normal">
        <div class="row">
          <div class="col col-lg-6 col-sm-12 col-xs-12">
            <div class="videos-ao-vivo">
              <div style="width: 100%;
                          height: 250px;
                          background-color: rgba(0,0,0,1);
                          color: rgba(255,255,255,1);
                          line-height: 250px;">
                Em Breve
              </div>
              <!--
              <object width="100%"
                      height="250"
                      data="https://www.youtube.com/v/tgbNymZ7vqY">
              </object>
              -->
              <div>ao vivo 1</div>
            </div>
          </div>

          <div class="col col-lg-6 col-sm-12 col-xs-12">
            <div class="videos-ao-vivo">
              <div style="width: 100%;
                          height: 250px;
                          background-color: rgba(0,0,0,1);
                          color: rgba(255,255,255,1);
                          line-height: 250px;">
                Em Breve
              </div>
              <!--
              <object width="100%"
                      height="250"
                      data="https://www.youtube.com/v/tgbNymZ7vqY">
              </object>
              -->
              <div>ao vivo 2</div>
            </div>
          </div>
        </div>
      </div>


      <div class="container ao-vivo-mobile">
        <div class="row">
          <div class="col col-lg-12">
            <div class="videos-ao-vivo">
              <div style="width: 100%;
                          height: 250px;
                          background-color: rgba(0,0,0,1);
                          color: rgba(255,255,255,1);
                          line-height: 250px;">
                Em Breve
              </div>
              <!--
              <object width="100%"
                      height="250"
                      data="https://www.youtube.com/v/tgbNymZ7vqY">
              </object>
              -->
              <div>ao vivo 1</div>
            </div>
          </div>
        </div>
        <br />
        <div class="row">
          <div class="col col-lg-12">
            <div class="videos-ao-vivo">
              <div style="width: 100%;
                          height: 250px;
                          background-color: rgba(0,0,0,1);
                          color: rgba(255,255,255,1);
                          line-height: 250px;">
                Em Breve
              </div>
              <!--
              <object width="100%"
                      height="250"
                      data="https://www.youtube.com/v/tgbNymZ7vqY">
              </object>
              -->
              <div>ao vivo 2</div>
            </div>
          </div>
        </div>
      </div>


      <div class="row align-items-center justify-content-center">
        <img src="imagens/videos.png"
             alt="Vídeos"
             class="img-info" />
      </div>

      <div class="container">
        <div class="row">
          <div class="col-1"></div>
          <div class="col-10">
            <div class="row">
              <div class="col" style="text-align: center;">
                <img src="imagens/campeira.png"
                     alt="Campeira"
                     class="img-videos" />
              </div>
              <div class="col" style="text-align: center;">
                <img src="imagens/artistica.png"
                     alt="Artística"
                     class="img-videos" />
              </div>
              <div class="col" style="text-align: center;">
                <img src="imagens/esporte.png"
                     alt="Esporte"
                     class="img-videos" />
              </div>
            </div>
          </div>
          <div class="col-1"></div>
        </div>
      </div>

      <div class="row align-items-center justify-content-center">
        <img src="imagens/40_rodeio.png"
             alt="40º Rodeio"
             class="img-info" />
      </div>

      <div class="container container-txt-rodeio">
        <div class="row">
          <div class="col-1"></div>
          <div class="col-10">
            <p>
              Entrando para sua 40º edição, que acontece entre os dias 2 e 11 de março
              de 2018, no Parque Municipal do Trabalhador, o Rodeio Nacional de
              Campo Bom é uma organização entre as entidades tradicionalistas
              CTG Campo Verde, CTG M'Bororé, CTG Guapos do Itapuí e Palanques da
              Tradição em parceiria com a Prefeitura Municipal.
            </p>
            <br /><br />
            <p>
              Desde sua primeira edição em 1978, o Rodeio de Campo Bom se mantém na
              rota dos principais rodeios crioulos artísticos do sul do Brasil. Mais
              do que fortalecer a cultura e tradições gaúchas, o Rodeio também é uma
              opção de lazer e diversão para toda a família. Além das atrações
              artísticas e culturais, o evento possui espaços para acampamento, que
              propicia uma aproximação ainda maior com o evento e suas raízes.
            </p>
          </div>
          <div class="col-1"></div>
        </div>
      </div>

      <div class="row align-items-center justify-content-center">
        <img src="imagens/programacao.png"
             alt="Programação"
             class="img-info" />
      </div>

      <div class="container container-txt">
        <div class="row">
          <div class="col-1"></div>
          <div class="col-10">

            <p class="data"><span>23/02 | Sexta-feira</span></p>
            <p><span>20h |</span> Abertura das inscrições dos concursos artísticos</p>
            <br /><br />

            <p class="data"><span>02/03 | Sexta-feira
            <p><span>20h |</span> Encerramento das inscrições dos concursos artísticos</p>

            <p>*Ordem de apresentação será inversa as inscrições.</p>

            <p><span>21h |</span> Publicação oficial dos inscritos conforme ordem de apresentação</p>
            <br /><br />

            <p class="data"><span>03/03 | Sábado</span></p>
            <p><span>22h |</span> Tchê Barbaridade</p>
            <br /><br />

            <p class="data"><span>08/03 | Quinta- Feira</span></p>
            <p><span>14h |</span> Provas Campeiras</p>
            <br /><br />

            <p class="data"><span>09/03 | Sexta-feira</span></p>
            <p><span>8h |</span> Provas Campeiras</p>
            <p><span>20h |</span> Abertura Oficial do Rodeio</p>
            <p><span>22h |</span> JJ&amp;SV</p>
            <br /><br />

            <p class="data"><span>10/03 | Sábado</span></p>
            <p><span>7h45min |</span> Abertura dos concursos - Palco "A"</p>
            <p><span>8h |</span> Provas Campeiras</p>
            <p><span>8h |</span> Início do concurso - Danças Tradicionais - Palco "A" - Categoria Mirim</p>
            <p><span>9h |</span> Provas de Esporte</p>
            <p><span>10h |</span> Início do concurso - Declamação Mirim e Juvenil Peão/Prenda - Palco "B"</p>
            <p><span>12h |</span> Intervalo para almoço</p>
            <p><span>13h |</span> Início do concurso - Danças Tradicionais - Palco "A" - Categoria Pré-Mirim</p>
            <p><span>14h |</span> Início do concurso - Intérprete Solista Vocal Mirim, Juvenil e
            Adulto Peão/Prenda - Palco "C"</p>
            <p><span>14h |</span> Início do concurso - Chula Mirim, Juvenil e Adulto - Palco "D"</p>
            <p><span>14h30min |</span> Início do concurso - Danças Tradicionais - Palco “A” - Categoria Juvenil</p>
            <p><span>20h |</span> Enceramento dos concursos</p>
            <p><span>21h |</span> Entrega das premiações</p>
            <p><span>22h |</span> Garotos de Ouro</p>
            <br /><br />

            <p class="data"><span>11/03 | Domingo</span></p>
            <p><span>8h |</span> Provas Campeiras</p>
            <p><span>9h |</span> Provas de Esporte</p>
            <p><span>9h |</span> Início do concurso - Danças Tradicionais - Palco "A" - Categoria Veterana</p>
            <p><span>12h |</span> Intervalo para almoço</p>
            <p><span>14h |</span> Início do concurso - Danças Tradicionais - Palco "A" - Categoria Adulta</p>
            <p><span>14h |</span> Início do concurso - Declamação Adulta Peão/Prenda - Palco "B"</p>
            <p><span>14h |</span> Início do concurso - Trova - Palco "D"</p>
            <p><span>19h |</span> Enceramento dos concursos</p>
            <p><span>20h |</span> Entrega das premiações</p>
          </div>
          <div class="col-1"></div>
        </div>
      </div>

      <div class="row align-items-center justify-content-center">
        <img src="imagens/localizacao.png"
             alt="Localização"
             class="img-info" />
      </div>

      <div class="container">
        <div class="row">
          <div class="col-1"></div>
          <div class="col-10">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6931.642277537613!2d-51.0699428693521!3d-29.695964887056263!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x951941c153dc4d3b%3A0x40a3d93ab69d5796!2sParque+do+Trabalhador!5e0!3m2!1spt-BR!2sbr!4v1518637636284" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
          </div>
          <div class="col-1"></div>
        </div>
      </div>

      <div class="row align-items-center justify-content-center">
        <img src="imagens/contato.png"
             alt="Contato"
             class="img-info" />
      </div>

      <div class="container container-txt">
        <div class="row">
          <div class="col-1"></div>
          <div class="col-10">
            <p><span>Patrão | CTG Campo Verde</span> - Dirceu Knevitz | 51 98122-2831</p>
            <p><span>Acampamentos | CTG Campo Verde</span></p>
            <p>Alexandre Soares | 51 99853-1500 - Lizandro Knevitz | 51 98122-2834</p>
            <p><span>Artística | CTG Guapos do Itapuí</span></p>
            <p>Everton Ferreira | 51 99828-5945 | rodeiodecampobom@gmail.com</p>
            <p><span>Campeira | CTG Campo Verde</span> - Ricardo Bilhalva | 51 99947-0020</p>
            <p><span>Comércio | CTG Campo Verde</span> - Juares Fontoura | 51 99971-5927</p>
            <p><span>Esporte | CTG Palanques da Tradição</span> - Marco Godoy | 51 98015-8073</p>
          </div>
          <div class="col-1"></div>
        </div>
      </div>

      <div class="container"
           style="background-color: rgba(255,255,255,1);
                  margin-bottom: 0px;
                  padding-top: 10px;
                  padding-bottom: 10px;
                  border-top: 3px solid green;">
        <div class="row">
          <div class="col-1"></div>
          <div class="col-10">
            <img src="imagens/apoio.jpg"
                 alt="Contato"
                 style="width: 100%" />
          </div>
          <div class="col-1"></div>
        </div>
      </div>

    </main>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
            integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
            crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
            integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
            crossorigin="anonymous"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js"
            integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4"
            crossorigin="anonymous"></script>


    <script type="text/javascript">
    (function($){$.fn.easyTabs=function(option){var param=jQuery.extend({fadeSpeed:"fast",defaultContent:1,activeClass:'active'},option);$(this).each(function(){var thisId="#"+this.id;if(param.defaultContent==''){param.defaultContent=1;}
    if(typeof param.defaultContent=="number")
    {var defaultTab=$(thisId+" .tabs li:eq("+(param.defaultContent-1)+") a").attr('href').substr(1);}else{var defaultTab=param.defaultContent;}
    $(thisId+" .tabs li a").each(function(){var tabToHide=$(this).attr('href').substr(1);$("#"+tabToHide).addClass('easytabs-tab-content');});hideAll();changeContent(defaultTab);function hideAll(){$(thisId+" .easytabs-tab-content").hide();}
    function changeContent(tabId){hideAll();$(thisId+" .tabs li").removeClass(param.activeClass);$(thisId+" .tabs li a[href=#"+tabId+"]").closest('li').addClass(param.activeClass);if(param.fadeSpeed!="none")
    {$(thisId+" #"+tabId).fadeIn(param.fadeSpeed);}else{$(thisId+" #"+tabId).show();}}
    $(thisId+" .tabs li").click(function(){var tabId=$(this).find('a').attr('href').substr(1);changeContent(tabId);return false;});});}})(jQuery);
    </script>

    <script type="text/javascript">
      $(window).scroll(function() {
        var height = $(window).scrollTop();
        if (height == 0) {
          $(".navbar-trans").css("background-color", "rgba(0, 0, 0, 0)");
        } else {
          $(".navbar-trans").css("background-color", "rgba(0, 0, 0, 0.35)");
        }
      });
    </script>
  </body>
</html>